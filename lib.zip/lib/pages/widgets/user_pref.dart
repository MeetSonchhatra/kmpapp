import 'package:agent/pages/widgets/user.dart';

class UserPreferences {
  static const myuser = User(
      imagePath: 'images/meet.png',
      name: 'Meet Sonchhatra',
      email: 'meetsonchhatra47@gmail.com',
      phonenum: '9737273154',
      isDarkMode: false);
}
