class orderrq {
  final String productname;
  final String quantity;
  final int reqorder;

const orderrq ({
required this.productname,
required this.quantity,
required this.reqorder,
});

}