import 'package:agent/pages/widgets/data.dart';
import 'package:agent/pages/widgets/orderreq.dart';
import 'package:flutter/material.dart';

class Orderpg extends StatefulWidget {
  const Orderpg({Key? key}) : super(key: key);

  @override
  State<Orderpg> createState() => _OrderpgState();
}

class _OrderpgState extends State<Orderpg> {
  late bool ascending ;
  @override
  void initstate() {
    super.initState();
    ascending = false;
  }

  @override
  Widget build(BuildContext context) {
    final width = 720 ;

    return SingleChildScrollView(
      // appBar: AppBar(
      //   title: const Center(child: Text('Order Page ')),
      //   backgroundColor: Colors.black,
      //   shape: const RoundedRectangleBorder(
      //       borderRadius: BorderRadius.only(
      //           bottomLeft: Radius.circular(25),
      //           bottomRight: Radius.circular(25))),
      // ),

      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: width * 1.4,
        child: ListView(
          children: <Widget>[buildDataTable()],
        ),
      ),
    );
  }

  Widget buildDataTable() => DataTable(
        sortAscending: ascending,
        sortColumnIndex: 0,
        columns: orderColumns
            .map((String column) => DataColumn(
                label: Text(column),
                onSort: (int columnIndex, bool ascending) => onSortColumn(
                    columnIndex: columnIndex, ascending: ascending),
                    ),
                    )
            .toList(),
        rows: orders
            .map((orderrq name) => DataRow(cells: [
                  DataCell(Text(name.productname)),
                  DataCell(Text(name.quantity)),
                  DataCell(Text('${name.reqorder}')),
                ]
                )).toList(),
      );

  void onSortColumn({required int columnIndex, required bool ascending}) {
    if (columnIndex == 0) {
      setState(() {
        if (ascending) {
          orders.sort((a, b) => a.productname.compareTo(b.productname));
        } else {
          orders.sort((a, b) => b.productname.compareTo(a.productname));
        }
        this.ascending = ascending;
      });
    }
  }
}
